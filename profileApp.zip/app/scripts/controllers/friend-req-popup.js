'use strict';

/**
 * @ngdoc function
 * @name profilePageApp.controller:FriendReqPopupCtrl
 * @description
 * # FriendReqPopupCtrl
 * Controller of the profilePageApp
 */
angular.module('profilePageApp')
  .controller('FriendReqPopupCtrl', ['$scope','$uibModalInstance','$timeout',function ($scope,$uibModalInstance,$timeout) {
    $scope.close = function () {
    	 /* body... */ 
    	 $uibModalInstance.close('cancel');
    }

    $scope.sendRequest = function () {
    	 /* body... */ 
         angular.element(".modal-body").text("Friend Request Sent");
         $timeout(function () {
              /* body... */
              $uibModalInstance.dismiss('sentRequest');
         },1000);
    	 
    }
  }]);
