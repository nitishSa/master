'use strict';

/**
 * @ngdoc function
 * @name profilePageApp.controller:EditProfilePopupCtrl
 * @description
 * # EditProfilePopupCtrl
 * Controller of the profilePageApp
 */
angular.module('profilePageApp')
  .controller('EditProfilePopupCtrl', ['$uibModalInstance','$scope',function ($uibModalInstance,$scope) {
    $scope.sendConfirmation = function () {
    	 $uibModalInstance.dismiss();
    }
    
  }]);
