'use strict';

/**
 * @ngdoc function
 * @name profilePageApp.controller:EditProfileCtrl
 * @description
 * # EditProfileCtrl
 * Controller of the profilePageApp
 */
angular.module('profilePageApp')
  .controller('EditProfileCtrl', ["$rootScope","$scope", "$uibModal",function ($rootScope,$scope,$uibModal) {
    $scope.user = angular.copy($rootScope.userProfile);

    $scope.clearPersonelInfo = function () {
    	 /* body... */ 
    	 if($scope.user){
    	 	$scope.user.name = "";
    	 	$scope.user.username = "";
    	 	$scope.user.email = "";
    	 	$scope.user.phone = "";	
    	 }
    	 
    }

    $scope.clearAddressInfo = function () {
    	 /* body... */ 
    	 if($scope.user){
 	   	 	$scope.user.address = {};
 	   	 }
    }

    $scope.clearCompanyInfo = function () {
    	 /* body... */ 
    	 if($scope.user){
    	 	$scope.user.company = {};
    	 }
    }

    $scope.clearAllInformation = function () {
    	 /* body... */ 
    	 $scope.clearPersonelInfo();
    	 $scope.clearAddressInfo();
    	 $scope.clearCompanyInfo();
    }

    $scope.saveAllInformation = function (isFormValid) {
    	 /* body... */ 


    	 if(isFormValid && $scope.user){
            
            var uibModalInstance = $uibModal.open({
                templateUrl : 'views/edit-profile-popup.html',
                controller : 'EditProfilePopupCtrl'
            });

            uibModalInstance.result.then(function(data) {
                
            },function () {
             /* body... */ 
              $rootScope.userProfile = angular.copy($scope.user);
            });


    	 		
    	 }
    	 
    }


  }]);
