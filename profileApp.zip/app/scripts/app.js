'use strict';

/**
 * @ngdoc overview
 * @name profilePageApp
 * @description
 * # profilePageApp
 *
 * Main module of the application.
 */
angular
  .module('profilePageApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'ui.bootstrap'
  ])
  .config(function ($routeProvider, $locationProvider) {
    $locationProvider.hashPrefix('');
    $routeProvider
      .when('/', {
        templateUrl: 'views/profile.html',
        controller: 'ProfileCtrl',
        controllerAs: 'profile'
      })
      .when('/profile/:profileId', {
        templateUrl: 'views/profile.html',
        controller: 'ProfileCtrl',
        controllerAs: 'profile'
      })
      .when('/search/:searchType', {
        templateUrl: 'views/search-friend.html',
        controller: 'SearchCtrl',
        controllerAs: 'search'
      })
      .when('/edit-profile', {
        templateUrl: 'views/edit-profile.html',
        controller: 'EditProfileCtrl',
        controllerAs: 'edit'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
