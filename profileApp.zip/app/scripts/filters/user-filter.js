'use strict';

/**
 * @ngdoc filter
 * @name profilePageApp.filter:userFilter
 * @function
 * @description
 * # userFilter
 * Filter in the profilePageApp.
 */
angular.module('profilePageApp')
  .filter('userFilter', ['$filter',function ($filter) {
    return function (input,userType) {
    	if(userType == 'friend'){
    		return $filter('filter')(input,{"isFriend" : true});
    	}
    	else if(userType == 'notAFriend'){
    		return $filter('filter')(input,{"isFriend" : false});
    	}
    	else{
    		return input
    	}
    };
  }]);
