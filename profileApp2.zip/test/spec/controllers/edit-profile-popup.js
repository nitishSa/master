'use strict';

describe('Controller: EditProfilePopupCtrl', function () {

  // load the controller's module
  beforeEach(module('profilePageApp'));

  var EditProfilePopupCtrl,
    scope;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    EditProfilePopupCtrl = $controller('EditProfilePopupCtrl', {
      $scope: scope
      // place here mocked dependencies
    });
  }));

  it('should attach a list of awesomeThings to the scope', function () {
    expect(EditProfilePopupCtrl.awesomeThings.length).toBe(3);
  });
});
