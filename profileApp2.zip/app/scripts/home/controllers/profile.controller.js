'use strict';

/**
 * @ngdoc function
 * @name profilePageApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the profilePageApp
 */
profile.controller('ProfileCtrl', [
  "$scope","$location","$routeParams","UserDataService","$rootScope",
  function ($scope,$location,$routeParams,UserDataService,$rootScope) {
    
    $scope.profileUser = {};
    $scope.mainUserProfile = true;

    if($location.path() == '/'){
      if($rootScope.userProfile){
        $scope.profileUser = $rootScope.userProfile;
      }
      else{
        $scope.profileUser = {
          "id": 1,
          "name": "Leanne Graham",
          "username": "Bret",
          "email": "Sincere@april.biz",
          "address": {
            "street": "Kulas Light",
            "suite": "Apt. 556",
            "city": "Gwenborough",
            "zipcode": "92998-3874",
            "geo": {
              "lat": "-37.3159",
              "lng": "81.1496"
            }
          },
        "imgUrl": "http://lorempixel.com/100/100/people?1",
          "phone": "1-770-736-8031 x56442",
          "website": "hildegard.org",
          "company": {
            "name": "Romaguera-Crona",
            "catchPhrase": "Multi-layered client-server neural-net",
            "bs": "harness real-time e-markets"
          }
        };

        $rootScope.userProfile = $scope.profileUser;
      }
    
    }
    else{
        $scope.mainUserProfile = false;
        var userDataPromise = UserDataService.getUserData();

        userDataPromise.then(function (response) {
           response.data.forEach( function(element, index) {
             if(element.id == $routeParams.profileId){
              $scope.profileUser = element;
             }
           }); 
        })
    }
    
  }]);
