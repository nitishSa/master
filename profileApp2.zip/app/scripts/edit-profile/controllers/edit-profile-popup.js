'use strict';

/**
 * @ngdoc function
 * @name profilePageApp.controller:EditProfilePopupCtrl
 * @description
 * # EditProfilePopupCtrl
 * Controller of the profilePageApp
 */
editProfile.controller('EditProfilePopupCtrl', ['$uibModalInstance','$scope',function ($uibModalInstance,$scope) {
    $scope.sendConfirmation = function () {
    	 $uibModalInstance.dismiss();
    }
    
  }]);
