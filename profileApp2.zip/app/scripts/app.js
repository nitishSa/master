'use strict';

/**
 * @ngdoc overview
 * @name profilePageApp
 * @description
 * # profilePageApp
 *
 * Main module of the application.
 */
angular
  .module('profilePageApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'ui.bootstrap',
    'ProfilePage',
    'SearchPage',
    'EditProfile',
    'CoreModule'
  ])
  .config(function ($routeProvider, $locationProvider) {
    $locationProvider.hashPrefix('');
    $routeProvider
      .when('/', {
        templateUrl: 'scripts/home/templates/profile.html',
        controller: 'ProfileCtrl',
        controllerAs: 'profile'
      })
      .when('/profile/:profileId', {
        templateUrl: 'scripts/home/templates/profile.html',
        controller: 'ProfileCtrl',
        controllerAs: 'profile'
      })
      .when('/search/:searchType', {
        templateUrl: 'scripts/search/templates/search-friend.html',
        controller: 'SearchCtrl',
        controllerAs: 'search'
      })
      .when('/edit-profile', {
        templateUrl: 'scripts/edit-profile/templates/edit-profile.html',
        controller: 'EditProfileCtrl',
        controllerAs: 'edit'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
