'use strict';

/**
 * @ngdoc function
 * @name profilePageApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the profilePageApp
 */

searchModule.controller('SearchCtrl', ["$scope","UserDataService","$routeParams","$uibModal",function ($scope,UserDataService,$routeParams,$uibModal	) {
    var userDataPromise = UserDataService.getUserData();
    $scope.users = [];
    $scope.searchType = $routeParams.searchType;

    $scope.sendFriendRequest = function (user) {
    	 console.log('opening popup');
    	 var uibModalInstance = $uibModal.open({
    	 	templateUrl : 'scripts/search/templates/friend-request-popup.html',
    	 	controller : 'FriendReqPopupCtrl'
    	 });

    	 uibModalInstance.result.then(function(data) {
      		user.isFriend = false;
    	 },function () {
    	 	 /* body... */ 
    	 	 user.isFriend = true;
    	 });
    }



    userDataPromise.then(function (response) {
    	 console.log("Data Captured by Service : "+JSON.stringify(response.data));
    	 $scope.users = response.data;
    });
  }]);
