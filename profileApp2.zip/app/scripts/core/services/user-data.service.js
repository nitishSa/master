'use strict';

core.factory('UserDataService', ['$http',function($http){
	var _url = "/data/user-data.json";

	return{
		getUserData : function () {
			 return $http({cache: true,method : 'GET', url : _url});
		}
	};
}])