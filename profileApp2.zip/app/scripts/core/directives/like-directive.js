'use strict';

/**
 * @ngdoc directive
 * @name profilePageApp.directive:likeDirective
 * @description
 * # likeDirective
 */
core.directive('likeDirective', function () {
    return {
      template: `
      <div class="like-component">
      	<i class="glyphicon glyphicon-heart fav" ng-class="{ 'pink' : isfavourite}"></i>
      </div>`,
      restrict: 'E',
      scope : {
      	isfavourite : '='
      },
      link : function (scope,element,attrs) {
         element.find('.fav').on('click',function () {
            element.find('.fav').toggleClass('pink');
            scope.isfavourite = !scope.isfavourite;
            console.log('scope.isfavourite:'+scope.isfavourite);
         })
      }
    };
  });
